# SigVerify — Offline Signature Verification with a Siamese CNN

Pipeline: preprocess (Otsu → denoise → crop → resize 128×256) → shared-weight CNN → 128-d L2-normalised
embedding → Euclidean distance → threshold (picked on validation data). Loss: contrastive. Web UI: Flask + HTML/JS.

## 1. Setup
    pip install -r requirements.txt

## 2. Dataset (CEDAR or BHSig260)
Put the extracted dataset anywhere; the loader scans recursively and understands the original file names:
- CEDAR: `original_<writer>_<n>.png`, `forgeries_<writer>_<n>.png`
- BHSig260: `<Lang>/<writer>/B-S-<writer>-G-<n>.tif` (genuine) and `...-F-<n>.tif` (forged)
Start with ONE dataset (as in Milestone 1/2).

## 3. Train + evaluate (writer-independent: test writers are never seen in training)
    python train.py --data path/to/CEDAR --epochs 40
Outputs: `models/siamese.pt` (weights + threshold), `reports/results.json`
(accuracy, precision, recall, F1, FAR, FRR, EER, AUC, confusion matrix) and `reports/evaluation.png`
(ROC, distance histogram, training curves). A GPU (Google Colab free tier is fine) makes this a few minutes.

## 4. Run the web app
    python app.py        # open http://127.0.0.1:5000

## 5. Milestone-style ablation (objective 8: preprocessing/augmentation study)
    python train.py --data DATA --no-aug --out models/noaug.pt     # compare reports/results.json
Rename `reports/results.json` between runs and tabulate the differences in your report.

## API
`POST /api/verify` (multipart: `reference`, `questioned`) → `{genuine, distance, threshold, similarity, ...}`

## If accuracy is lower than you want
1. Train longer (`--epochs 60 --pairs 40000`); 2. lower/raise `p_skilled` in `data.make_pairs`;
3. try `--lr 5e-4`; 4. check the distance histogram — heavy overlap means more epochs/data are needed.
