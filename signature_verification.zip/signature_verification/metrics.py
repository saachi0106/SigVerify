"""Verification metrics. Convention: positive = genuine match; d = embedding distance."""
import numpy as np
from sklearn.metrics import roc_curve, roc_auc_score


def best_threshold(d, y):
    """Pick the distance threshold with the highest accuracy on validation data."""
    cands = np.unique(d)
    accs = [((d <= t).astype(int) == y).mean() for t in cands]
    return float(cands[int(np.argmax(accs))])


def compute_metrics(d, y, thr):
    pred = (d <= thr).astype(int)
    tp = int(((pred == 1) & (y == 1)).sum()); tn = int(((pred == 0) & (y == 0)).sum())
    fp = int(((pred == 1) & (y == 0)).sum()); fn = int(((pred == 0) & (y == 1)).sum())
    prec = tp / max(tp + fp, 1); rec = tp / max(tp + fn, 1)
    fpr, tpr, _ = roc_curve(y, -d)
    i = int(np.argmin(np.abs(fpr - (1 - tpr))))
    return {
        "threshold": thr, "accuracy": (tp + tn) / len(y), "precision": prec, "recall": rec,
        "f1": 2 * prec * rec / max(prec + rec, 1e-9),
        "FAR": fp / max(fp + tn, 1),   # forgeries wrongly accepted
        "FRR": fn / max(fn + tp, 1),   # genuine wrongly rejected
        "EER": float((fpr[i] + 1 - tpr[i]) / 2), "AUC": float(roc_auc_score(y, -d)),
        "confusion": {"TP": tp, "TN": tn, "FP": fp, "FN": fn},
    }
