"""Train + evaluate. Usage:  python train.py --data path/to/CEDAR --epochs 40"""
import argparse, json, math, time
from pathlib import Path
import numpy as np, torch, torch.nn.functional as F
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve
from data import load_dataset, split_writers, make_pairs
from metrics import best_threshold, compute_metrics
from model import SiameseNet, contrastive_loss
from preprocess import H, W


def augment(x, rot=6, scale=0.10, shift=0.05):
    """Random small rotation / scale / translation on a batch (B,1,H,W)."""
    B = x.size(0)
    r = lambda m: (torch.rand(B, device=x.device) * 2 - 1) * m
    a, s = r(rot) * math.pi / 180, 1 + r(scale)
    c, si = torch.cos(a) / s, torch.sin(a) / s
    theta = torch.stack([torch.stack([c, -si, r(shift)], 1), torch.stack([si, c, r(shift)], 1)], 1)
    return F.grid_sample(x, F.affine_grid(theta, x.shape, align_corners=False), align_corners=False)


@torch.no_grad()
def eval_pairs(model, X, pairs, dev):
    model.eval()
    emb = torch.cat([model.embed(torch.from_numpy(X[i:i + 256]).float().div(255).unsqueeze(1).to(dev)).cpu()
                     for i in range(0, len(X), 256)])
    A, B, Y = pairs
    return (emb[A] - emb[B]).pow(2).sum(1).sqrt().numpy(), Y


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True); ap.add_argument("--epochs", type=int, default=40)
    ap.add_argument("--pairs", type=int, default=20000, help="train pairs per epoch (resampled each epoch)")
    ap.add_argument("--bs", type=int, default=64); ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--patience", type=int, default=8); ap.add_argument("--no-aug", action="store_true")
    ap.add_argument("--seed", type=int, default=42); ap.add_argument("--out", default="models/siamese.pt")
    a = ap.parse_args()
    torch.manual_seed(a.seed); rng = np.random.RandomState(a.seed)
    dev = "cuda" if torch.cuda.is_available() else "cpu"

    X, index = load_dataset(a.data)
    tr, va, te = split_writers(index.keys(), a.seed)
    print(f"{len(X)} images | writers train/val/test = {len(tr)}/{len(va)}/{len(te)} | device={dev}")
    val_pairs = make_pairs(index, va, 4000, np.random.RandomState(1))
    test_pairs = make_pairs(index, te, 8000, np.random.RandomState(2))

    model = SiameseNet().to(dev)
    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=1e-4)
    steps = a.epochs * math.ceil(a.pairs / a.bs)
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, a.lr, total_steps=steps)
    Xt = torch.from_numpy(X)
    best, bad, hist = -1, 0, []

    for ep in range(1, a.epochs + 1):
        model.train(); t0 = time.time(); tot = 0
        A, B, Y = make_pairs(index, tr, a.pairs, rng)          # fresh pairs every epoch
        perm = rng.permutation(len(Y))
        for k in range(0, len(perm) - a.bs + 1, a.bs):
            ix = perm[k:k + a.bs]
            x1 = Xt[A[ix]].float().div(255).unsqueeze(1).to(dev)
            x2 = Xt[B[ix]].float().div(255).unsqueeze(1).to(dev)
            y = torch.from_numpy(Y[ix]).float().to(dev)
            if not a.no_aug:
                x1, x2 = augment(x1), augment(x2)
            loss = contrastive_loss(model(x1, x2), y)
            opt.zero_grad(); loss.backward(); opt.step(); sched.step(); tot += loss.item()
        d, y = eval_pairs(model, X, val_pairs, dev)
        thr = best_threshold(d, y); m = compute_metrics(d, y, thr)
        hist.append({"epoch": ep, "loss": tot / (len(perm) // a.bs), "val_acc": m["accuracy"], "val_auc": m["AUC"]})
        print(f"ep {ep:02d} loss {hist[-1]['loss']:.4f} val_acc {m['accuracy']:.4f} auc {m['AUC']:.4f} ({time.time()-t0:.0f}s)")
        if m["accuracy"] > best:
            best, bad = m["accuracy"], 0
            Path(a.out).parent.mkdir(exist_ok=True)
            torch.save({"state": model.state_dict(), "threshold": thr, "H": H, "W": W}, a.out)
        else:
            bad += 1
            if bad >= a.patience:
                print("early stopping"); break

    # ---- final writer-independent test with the checkpoint's validation-chosen threshold ----
    ck = torch.load(a.out, map_location=dev); model.load_state_dict(ck["state"])
    d, y = eval_pairs(model, X, test_pairs, dev)
    res = compute_metrics(d, y, ck["threshold"]); res["history"] = hist
    Path("reports").mkdir(exist_ok=True)
    json.dump(res, open("reports/results.json", "w"), indent=2)
    print({k: (round(v, 4) if isinstance(v, float) else v) for k, v in res.items() if k != "history"})

    fpr, tpr, _ = roc_curve(y, -d)
    fig, ax = plt.subplots(1, 3, figsize=(15, 4))
    ax[0].plot(fpr, tpr); ax[0].plot([0, 1], [0, 1], "--"); ax[0].set(title=f"ROC (AUC={res['AUC']:.3f})", xlabel="FAR", ylabel="1 - FRR")
    ax[1].hist(d[y == 1], 40, alpha=.6, label="genuine"); ax[1].hist(d[y == 0], 40, alpha=.6, label="forged / other")
    ax[1].axvline(ck["threshold"], c="k", ls="--"); ax[1].legend(); ax[1].set(title="Distance distribution", xlabel="distance")
    ax[2].plot([h["loss"] for h in hist], label="train loss"); ax[2].plot([h["val_acc"] for h in hist], label="val acc")
    ax[2].legend(); ax[2].set(title="Training", xlabel="epoch")
    plt.tight_layout(); plt.savefig("reports/evaluation.png", dpi=120)


if __name__ == "__main__":
    main()
