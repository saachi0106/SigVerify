"""Dataset scanning, writer-independent splitting and pair generation (numpy only)."""
import re
from pathlib import Path
import numpy as np
from preprocess import preprocess

EXT = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"}
CEDAR = re.compile(r"(original|forgeries)_(\d+)_(\d+)", re.I)   # original_12_3.png
BHSIG = re.compile(r"S-(\d+)-([GF])-(\d+)", re.I)               # B-S-12-G-03.tif


def scan(root):
    """-> {writer: {'gen': [paths], 'forg': [paths]}} for CEDAR or BHSig260 naming."""
    out = {}
    for p in sorted(Path(root).rglob("*")):
        if p.suffix.lower() not in EXT:
            continue
        m = CEDAR.search(p.name)
        if m:
            kind, w = ("gen" if m[1].lower() == "original" else "forg"), "c" + m[2]
        else:
            m = BHSIG.search(p.name)
            if not m:
                continue
            kind, w = ("gen" if m[2].upper() == "G" else "forg"), str(p.parent)
        out.setdefault(w, {"gen": [], "forg": []})[kind].append(p)
    return {w: v for w, v in out.items() if len(v["gen"]) >= 2}


def load_dataset(root, cache="models/cache.npz"):
    """Preprocess every image once. Returns X (N,H,W) uint8 and {writer: (gen_idx, forg_idx)}."""
    cache = Path(cache)
    w2f = scan(root)
    if not w2f:
        raise SystemExit(f"No signatures found under {root} (check README for naming).")
    key = f"{len(w2f)}-{sum(len(v['gen']) + len(v['forg']) for v in w2f.values())}"
    if cache.exists():
        z = np.load(cache, allow_pickle=True)
        if str(z["key"]) == key:
            return z["X"], z["index"].item()
    X, index = [], {}
    for w, v in w2f.items():
        g, f = [], []
        for kind, lst in (("gen", g), ("forg", f)):
            for p in v[kind]:
                lst.append(len(X)); X.append(preprocess(p))
        index[w] = (g, f)
    X = np.stack(X)
    cache.parent.mkdir(exist_ok=True)
    np.savez_compressed(cache, X=X, index=np.array(index, dtype=object), key=key)
    return X, index


def split_writers(writers, seed=42, ratios=(0.7, 0.1, 0.2)):
    """Writer-independent split: test writers are NEVER seen in training."""
    w = sorted(writers)
    np.random.RandomState(seed).shuffle(w)
    a, b = int(len(w) * ratios[0]), int(len(w) * (ratios[0] + ratios[1]))
    return w[:a], w[a:b], w[b:]


def make_pairs(index, writers, n, rng, p_skilled=0.7):
    """Balanced pairs. label 1 = same writer & genuine, 0 = forged / different writer.
    Negatives: p_skilled = genuine vs skilled forgery of the SAME writer (hard),
    rest = genuine vs another writer's genuine (random forgery)."""
    ws = [w for w in writers if len(index[w][0]) >= 2]
    A, B, Y = [], [], []
    for k in range(n):
        w = ws[rng.randint(len(ws))]
        g, f = index[w]
        if k % 2 == 0:
            i, j = rng.choice(len(g), 2, replace=False)
            A.append(g[i]); B.append(g[j]); Y.append(1)
        else:
            a = g[rng.randint(len(g))]
            if f and rng.rand() < p_skilled:
                b = f[rng.randint(len(f))]
            else:
                w2 = ws[rng.randint(len(ws))]
                while w2 == w and len(ws) > 1:
                    w2 = ws[rng.randint(len(ws))]
                b = index[w2][0][rng.randint(len(index[w2][0]))]
            A.append(a); B.append(b); Y.append(0)
    return np.array(A), np.array(B), np.array(Y)
